import re
from os import getenv

from dotenv import load_dotenv
from pyrogram import filters

load_dotenv()


OWNER = ["NP_DZ"]
KeroId = 7395381693
OWNER_NAME = "『 ᥎Ꭵ᥉ᥴ᥆ ძᥱ᥎ 』"
BOT_TOKEN = "7113605657:AAH2u5Qaee9YYGFhc6gzUO0e9XCIvXLHovk"
DATABASE = "mongodb+srv://DevKERO:DevKERO123@kero.ljshi.mongodb.net/?retryWrites=true&w=majority&appName=KERO"
CHANNEL = "https://t.me/rb_ot"
GROUP = "https://t.me/rb_ot"
VID_SO = "https://t.me/CACASF4235/3"
VIDEO = "https://t.me/CACASF4235/3"
PHOTO = "https://t.me/DL_SQ/30"
LOGS = "rb_ot"
