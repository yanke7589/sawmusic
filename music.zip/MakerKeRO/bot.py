from pyrogram import Client, idle
from config import API_ID, API_HASH, BOT_TOKEN
from pyromod import listen



bot = Client(
    "KeRo",
    api_id="29835032",
    api_hash="8bbbe06dbe125cf7ce67d70d8d7eac2b",
    bot_token="7113605657:AAH2u5Qaee9YYGFhc6gzUO0e9XCIvXLHovk",
    plugins=dict(root="MakerKeRo")
    )

async def start_bot():
    print("[INFO]: STARTING BOT CLIENT")
    await bot.start()
    USER = "NP_DZ"
    await bot.send_message(USER, "**تم تشغيل ال صانع بنجاح عزيزي المطور ...🥀،**")
    print("[INFO]: تم تشغيل الصانع وارسال رسالة للمطور⚡🚦.")
    await idle()
